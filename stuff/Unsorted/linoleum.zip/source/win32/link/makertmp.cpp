/*

	Make RTM variants pack.
	part of LINOLEUM Universal Compiler source code
	C++ Version 1.13.9b - first multiplatform release

	The contents of this archive are subject to the WTOF Public License;
	you may not use this archive except in full compliance with the
	License. You should have received a copy of the License within this
	archive; if not, you may obtain a copy of the License at
	http://anywherebb.com/wpl/wtof_public_license.html

	This archive (and related source code) is Copyright (C)2001-2003
	Alessandro Ghignola

	All Rights Reserved.

	MAKERTMP.CPP
	------------
	Reads RTM01.bin throught RTM??.bin (?? <= 64)
	and concatenates them into a single file also
	prepending the mappings, as follows...

	offset 0 - DWORD - number of RTM instances (variants) found (=n)
	offset 4 - n DWORDS - offsets of all RTM instances in pack file
	offset 4 + 4*n - n DWORDS - length in bytes of each RTM instance
	offset 4 + 4*n + 4*n - beginning of first instance (RTM01.bin)

	the resulting RTMP will be called "RTMP.bin",
	but might be renamed to whatever system it contains RTMs for,
	such as "win32.bin" for what concerns the Win32 platform.

	BTW - this program compiled and worked perfectly at its first build :p
	      heh, ok, it was simple...

*/

#include <stdlib.h>
#include <stdio.h>
#include <io.h>

char iobuffer[4096];

int main ()
{
	char	rtmfilename[13];
	int	ih, oh;
	int	to_write, written;
	long	size_now;

	long	count = 0;
	long	variants = 0;
	long	offset_now = 0;
	long	header_size = 0;

	oh = _creat ("RTMP.bin", 0);
	if (oh > -1) {
		// count how many variants can be found
		while (variants < 64) {
			sprintf (rtmfilename, "RTM%02d.bin", variants + 1);
			ih = _open (rtmfilename, 0);
			if (ih > -1) {
				_close (ih);
				variants++;
			}
			else
				break;
		}
		// write number of variants at beginning of RTMP.bin
		write (oh, &variants, 4);
		// calc. header size
		header_size = 4L + variants * 4L + variants * 4L;
		// change RTMP.bin's size to make room for the header
		chsize (oh, header_size);
		printf ("Variants to concatenate: %ld\n", variants);
		printf ("RTMP packet header size: %06lXh bytes\n", header_size);
		// start concatenating the variants...
		while (count < variants) {
			sprintf (rtmfilename, "RTM%02ld.bin", count + 1);
			ih = _open (rtmfilename, 0);
			if (ih > -1) {
				offset_now = lseek (oh, 0L, SEEK_END);
				offset_now -= header_size;
				size_now = 0;
				while ((to_write = _read (ih, iobuffer, 4096)) > 0) {
					written = _write (oh, iobuffer, to_write);
					if (written != to_write) {
						_close (ih);
						_close (oh);
						printf ("Write error concatenating variant: %s.\n", rtmfilename);
						return (0xFF);
					}
					size_now += written;
				}
				_close (ih);
				lseek (oh, 4L + count * 4L, SEEK_SET);
				_write (oh, &offset_now, 4L);
				lseek (oh, 4L + variants * 4L + count * 4L, SEEK_SET);
				_write (oh, &size_now, 4);
				printf ("Variant %s, offset: %06lXh (bytes past header), size: %06lXh (bytes)\n", rtmfilename, offset_now, size_now);
				count++;
			}
			else {
				printf ("File open error reading variant: %s.\n", rtmfilename);
				break;
			}
		}
		// end, succeeded.
		printf ("RTM variants concatenated to RTMP.bin: %ld\n", count);
		_close (oh);
		return (0x00);
	}
	else {
		// end, can't create RTMP.bin.
		printf ("Error creating output file handle for: RTMP.bin\n");
		return (0xFF);
	}
}
