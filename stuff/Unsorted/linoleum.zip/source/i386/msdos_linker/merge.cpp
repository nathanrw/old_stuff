#include <stdio.h>
#include <fcntl.h>
#include <dos.h>
#include <io.h>

int main ()
{
	int fhi, fho, c;
	char buffer[16384];

	fho=open(_argv[1], O_RDWR);
	if (fho==-1) fho = _creat (_argv[1], 0);

	if (fho > -1) {
		lseek (fho, 0L, SEEK_END);
		if ((fhi=_open(_argv[2], O_RDONLY)) > -1) {
			ripeti:
			c = _read (fhi, &buffer[0], sizeof(buffer));
			if (c>0) {
				if (_write (fho, &buffer[0], c) != c) {
					printf ("Mancanza di spazio. Files: %s e %s\n---> MERGE FALLITO!\n", _argv[1], _argv[2]);
					_close (fhi);
					_close (fho);
					return (1);
				}
				goto ripeti;
			}
			else {
				printf ("%s <++ %s [%ld <++ %ld => %ld]\n", _argv[1], _argv[2], filelength(fho)-filelength(fhi), filelength(fhi), filelength(fho));
				_close (fhi);
				_close (fho);
			}
		}
		else {
			printf ("Impossibile aprire il secondo file, ovvero: %s.\n", _argv[2]);
			_close (fho);
		}
	}
	else
		printf ("Impossibile ingrandire il primo file, ovvero: %s.\n", _argv[1]);

	return (0);
}