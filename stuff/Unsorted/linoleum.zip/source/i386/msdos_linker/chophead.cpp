#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <dos.h>
#include <io.h>

void main ()
{
	if (_argc<3) {
		printf ("Please run again typing file name and number of bytes to chop.\n");
		printf ("Example:\n\n");
		printf ("\tChopHead FILE.EXT 1254\n");
		return;
	}

	int 	hh, fh = _open (_argv[1], O_RDWR);
	char 	buffer[32000];
	long 	ltot, lreq;
	int 	c, w;

	if (fh>-1) {
		ltot = filelength (fh);
		lreq = strtol (_argv[2], 0, 10);
		if (lreq>ltot || lreq < 0)
			printf ("Invalid size.\n");
		else {
			lseek (fh, lreq, SEEK_SET);
			hh = _creat ("CHOPHEAD.TMP", 0);
			if (hh>-1) {
				while ((c = _read(fh, buffer, 32000))>0) {
					w = _write (hh, buffer, c);
					if (w<c) {
						_close (hh);
						_close (fh);
						remove ("CHOPHEAD.TMP");
						goto diskerr;
					}
				}
				_close (hh);
				_close (fh);
				remove (_argv[1]);
				rename ("CHOPHEAD.TMP", _argv[1]);
				return;
			}
			diskerr:
			printf ("\nDisk must be unprotected and have AT LEAST enough free\n");
			printf ("space to hold the resulting (chopped) file.\n");
		}
	}
	else
		printf ("File %s is not available.\n", _argv[1]);
}