""" simpleGe.py 
    example of simplest possible
    game engine program
"""

import pygame, gameEngine

game = gameEngine.Scene()
game.start()
