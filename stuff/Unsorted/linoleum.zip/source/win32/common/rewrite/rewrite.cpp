#include <stdlib.h>
#include <string.h>
#include <alloc.h>
#include <stdio.h>
#include <dos.h>
#include <io.h>

char far *farbuffer = (char far *) farmalloc (16384);

void main ()
{
	int 	f1, f2, pc;
	long	entryp;

	if (!farbuffer) {
		printf ("REWRITE: Not enough memory to proceed.\n");
		return;
	}

	if (_argc < 6 || stricmp (_argv[2], "with") || stricmp (_argv[4], "at")) {
		printf ("REWRITE <destfile> WITH <sourcefile> AT <decimal position>\n");
		return;
	}

	f1 = _open (_argv[1], 4);
	f2 = _open (_argv[3], 0);

	if (f1 == -1) {
		printf ("REWRITE:\tDestination file not accessible.\n");
		printf ("\t\tDestination file was: %s\n", _argv[1]);
		goto quit;
	}

	if (f2 == -1) {
		printf ("REWRITE: Source file not accessible.\n");
		printf ("\t\tSource file was: %s\n", _argv[3]);
		goto quit;
	}

	entryp = atol (_argv[5]);

	if (entryp < 0 || entryp > filelength (f1)) {
		printf ("REWRITE: Invalid entry point or write operation beyond file size.\n");
		printf ("\t\tSpecified entry point: %ld\n", entryp);
		printf ("\t\tData source file size: %ld\n", filelength(f2));
		printf ("\t\tDestination file size: %ld\n", filelength(f1));
		printf ("\t\tLast byte to re-write: %ld\n", entryp + filelength(f2));
		goto quit;
	}

	lseek (f1, entryp, SEEK_SET);

	while ((pc = _read (f2, farbuffer, 16384)) > 0)
		_write (f1, farbuffer, pc);

	printf ("REWRITE: operation complete.\n");

quit:	_close (f1);
	_close (f2);
}