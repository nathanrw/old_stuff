Module Things

    Public Function Multiliner(ByVal thestring, ByVal linelength)
        Dim newstring As String = ""
        Dim numlines As Integer = Len(thestring) \ linelength
        Dim Tilt As Integer = 0
        For Counter As Integer = 0 To numlines
            For CounterTwo As Integer = 0 To linelength
                Try
                    newstring = newstring & thestring.Substring(CounterTwo + Tilt)
                Catch
                    Return newstring
                End Try
            Next
            newstring = newstring & vbCrLf
            Tilt += Tilt
        Next
        Return newstring
    End Function

End Module
